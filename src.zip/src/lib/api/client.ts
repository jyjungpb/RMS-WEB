

// // src/lib/api/client.ts
// import axios, { AxiosError, AxiosRequestConfig,AxiosHeaders, type InternalAxiosRequestConfig } from "axios";

// import { API_CONFIG, API_ENDPOINTS } from "@/types";

// /**
//  * axios 인스턴스
//  * - withCredentials: 쿠키 자동 전송/수신
//  * - baseURL: .env 또는 타입 상수에서 가져오기
//  */
// export const apiClient = axios.create({
//   baseURL: API_CONFIG.BASE_URL,   // 예: http://43.200.x.x:30080
//   withCredentials: true,          // ★ HttpOnly 쿠키 자동 전송/수신
//   headers: {
//     "Content-Type": "application/json",
//   },
// });

// // ====== AccessToken 자동 첨부 ======

// apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
//   const at = typeof window !== "undefined" ? localStorage.getItem("accessToken") : null;
//   if (at) {
//     // headers가 비어 있으면 생성
//     if (!config.headers) {
//       config.headers = new AxiosHeaders();
//     }

//     // AxiosHeaders 인스턴스인 경우
//     if (config.headers instanceof AxiosHeaders) {
//       config.headers.set("Authorization", `Bearer ${at}`);
//     } else {
//       // 일반 객체인 경우
//       (config.headers as Record<string, string>)["Authorization"] = `Bearer ${at}`;
//     }
//   }
//   return config;
// });

// // ====== 401 → refresh 재발급 & 원요청 재시도 ======
// let isRefreshing = false;
// let queue: Array<(token: string) => void> = [];

// apiClient.interceptors.response.use(
//   (res) => res,
//   async (error: AxiosError) => {
//     const original = error.config as (AxiosRequestConfig & { _retry?: boolean });
//     const status = error.response?.status;

//     // access token 만료 등
//     if (status === 401 && !original?._retry) {
//       original._retry = true;

//       if (!isRefreshing) {
//         isRefreshing = true;
//         try {
//           /**
//            * ★ refreshToken은 HttpOnly 쿠키라 JS에서 못 읽음
//            *    → withCredentials:true로 /refresh 호출하면
//            *      브라우저가 쿠키를 자동으로 전송하고,
//            *      서버가 그 쿠키를 읽어 새 accessToken을 발급함.
//            */
//           const r = await apiClient.post(API_ENDPOINTS.AUTH.REFRESH, {});
//           const newAT =
//             (r.data as any)?.content?.accessToken ||
//             (r.data as any)?.accessToken; // 서버 응답 형태 둘 다 대응

//           if (newAT) {
//             localStorage.setItem("accessToken", newAT);
//             // 대기중인 요청들 이어붙이기
//             queue.forEach((cb) => cb(newAT));
//             queue = [];
//           }

//           // 원요청 재시도
//           return apiClient(original);
//         } catch (e) {
//           queue = [];
//           // 갱신 실패 → 로그인 만료 처리
//           if (typeof window !== "undefined") {
//             localStorage.removeItem("accessToken");
//           }
//           throw e;
//         } finally {
//           isRefreshing = false;
//         }
//       }

//       // 다른 요청들은 refresh 완료될 때까지 대기
//       return new Promise((resolve) => {
//         queue.push((token: string) => {
//           original.headers = {
//             ...(original.headers || {}),
//             Authorization: `Bearer ${token}`,
//           };
//           resolve(apiClient(original));
//         });
//       });
//     }

//     // 그 외 에러는 그대로 throw
//     throw error;
//   }
// );


// // --- 전역 에러 핸들러 등록 유틸 ---
// // 핸들러를 등록하고, 해제 함수(eject)를 반환합니다.
// export function registerGlobalErrorHandler(
//   handler: (title?: string, message?: string, subMessage?: string) => void
// ) {
//   const id = apiClient.interceptors.response.use(
//     (res) => res,
//     (error) => {
//       const status = error?.response?.status;
//       // 401은 이미 refresh 인터셉터에서 처리하므로 여기선 팝업 띄우지 않음
//       if (status !== 401) {
//         const serverMsg =
//           (error?.response?.data as any)?.message ??
//           error?.message ??
//           "요청 처리 중 오류가 발생했습니다.";
//         handler("오류", serverMsg, "");
//       }
//       return Promise.reject(error);
//     }
//   );
//   return () => apiClient.interceptors.response.eject(id);
// }




import axios, { AxiosError, AxiosHeaders, InternalAxiosRequestConfig } from "axios";
import { API_CONFIG } from "@/types/api/config";

export const apiClient = axios.create({
  baseURL: API_CONFIG.BASE_URL,
  withCredentials: true, // ★ HttpOnly 쿠키 자동 전송/수신
  headers: { "Content-Type": "application/json" },
  timeout: API_CONFIG.TIMEOUT,
});

// ===== 요청 인터셉터: Access Token 자동 첨부 =====
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const at = typeof window !== "undefined" ? localStorage.getItem("accessToken") : null;
  if (at) {
    if (!config.headers) config.headers = new AxiosHeaders();
    if (config.headers instanceof AxiosHeaders) {
      config.headers.set("Authorization", `Bearer ${at}`);
    } else {
      (config.headers as any)["Authorization"] = `Bearer ${at}`;
    }
  }
  return config;
});

let isRefreshing = false;
let queue: Array<(token: string) => void> = [];

// ===== 응답 인터셉터: 401 → refresh → 원요청 재시도 =====
apiClient.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const original = error.config as (InternalAxiosRequestConfig & { _retry?: boolean });
    const status = error.response?.status;

    if (status === 401 && !original?._retry) {
      original._retry = true;

      if (!isRefreshing) {
        isRefreshing = true;
        try {
          const r = await apiClient.post(API_CONFIG.REFRESH_PATH, {});
          const newAT =
            (r.data as any)?.content?.accessToken ??
            (r.data as any)?.accessToken;

          if (newAT) {
            localStorage.setItem("accessToken", newAT);
            queue.forEach((cb) => cb(newAT));
            queue = [];
          }

          return apiClient(original);
        } catch (e) {
          queue = [];
          if (typeof window !== "undefined") localStorage.removeItem("accessToken");
          throw e;
        } finally {
          isRefreshing = false;
        }
      }

      return new Promise((resolve) => {
        queue.push((token: string) => {
          if (!original.headers) original.headers = new AxiosHeaders();
          if (original.headers instanceof AxiosHeaders) {
            original.headers.set("Authorization", `Bearer ${token}`);
          } else {
            (original.headers as any)["Authorization"] = `Bearer ${token}`;
          }
          resolve(apiClient(original));
        });
      });
    }

    return Promise.reject(error);
  }
);

// ===== 전역 에러 핸들러 등록 유틸(선택) =====
export function registerGlobalErrorHandler(
  handler: (title?: string, message?: string, subMessage?: string) => void
) {
  const id = apiClient.interceptors.response.use(
    (res) => res,
    (error: AxiosError) => {
      if (error.response?.status !== 401) {
        const serverMsg =
          (error.response?.data as any)?.message ??
          error.message ??
          "요청 처리 중 오류가 발생했습니다.";
        handler("오류", serverMsg, "");
      }
      return Promise.reject(error);
    }
  );
  return () => apiClient.interceptors.response.eject(id);
}
