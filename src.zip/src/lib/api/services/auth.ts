import { apiClient } from "../client";
import { API_ENDPOINTS } from "@/types/api/endpoints";
import type { ApiResult, LoginReqDto, LoginResDto } from "@/types/api/models";

export async function login(body: LoginReqDto) {
  const { data } = await apiClient.post<ApiResult<LoginResDto>>(API_ENDPOINTS.AUTH.LOGIN, body);
  const at = data?.content?.accessToken;
  if (data?.success && at) localStorage.setItem("accessToken", at);
  return data;
}

export async function refresh() {
  const { data } = await apiClient.post<ApiResult<LoginResDto>>(API_ENDPOINTS.AUTH.REFRESH, {});
  const at = data?.content?.accessToken;
  if (data?.success && at) localStorage.setItem("accessToken", at);
  return data;
}

export async function logout() {
  // 서버가 refreshToken 쿠키 만료(Set-Cookie)로 처리한다고 가정
  const { data } = await apiClient.post<ApiResult>(API_ENDPOINTS.AUTH.LOGOUT, {});
  localStorage.removeItem("accessToken");
  return data;
}
