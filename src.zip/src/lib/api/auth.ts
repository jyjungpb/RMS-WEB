// 인증 관련 API 함수들
import axios, { AxiosError } from "axios";
import { apiClient } from "./client";
import {
  LoginRequest,
  LoginResponse,
  AUTH_ERROR_CODES,
} from "@/types";
import { API_ENDPOINTS } from "@/types";

/**
 * 로그인 API
 * - 1차: JSON
 * - 2차: x-www-form-urlencoded (403 등에서만 재시도)
 * - 성공 시 accessToken 저장
 */
export const login = async (loginData: LoginRequest): Promise<LoginResponse> => {
  try {
    // 1차: JSON 전송
    const jsonResp = await apiClient.post<LoginResponse>(
      API_ENDPOINTS.AUTH.LOGIN,
      loginData
    );

    const data1 = jsonResp.data;
    // 성공 시 accessToken 저장
    const at1 = (data1 as any)?.content?.accessToken;
    if (data1?.success && at1) {
      saveAccessToken(at1);
    }
    return data1;
  } catch (err) {
    // 403일 때만 form 재시도 (필요 시 415/400 등 조건 추가 가능)
    if (axios.isAxiosError(err) && err.response?.status === 403) {
      try {
        const formBody = new URLSearchParams({
          email: loginData.email,
          password: loginData.password,
        });

        const formResp = await apiClient.post<LoginResponse>(
          API_ENDPOINTS.AUTH.LOGIN,
          formBody.toString(),
          { headers: { "Content-Type": "application/x-www-form-urlencoded" } } // ★ 세 번째 인자가 config
        );

        const data2 = formResp.data;
        const at2 = (data2 as any)?.content?.accessToken;
        if (data2?.success && at2) {
          saveAccessToken(at2);
        }
        return data2;
      } catch (err2) {
        if (axios.isAxiosError(err2) && err2.response?.data) {
          return err2.response.data as LoginResponse;
        }
        return {
          success: false,
          status: 500,
          message: "로그인 처리 중 오류가 발생했습니다.",
        };
      }
    }

    // 서버가 에러 바디를 리턴했다면 그대로 전달
    if (axios.isAxiosError(err) && err.response?.data) {
      return err.response.data as LoginResponse;
    }

    // 예상치 못한 에러
    return {
      success: false,
      status: 500,
      message: "로그인 처리 중 오류가 발생했습니다.",
    };
  }
};

/**
 * 로그인 에러 메시지 변환
 */
export const getLoginErrorMessage = (response: LoginResponse): string => {
  if (response.success) return "";

  switch (response.code) {
    case AUTH_ERROR_CODES.USER_NOT_FOUND:
      return "이메일 또는 비밀번호가 올바르지 않습니다.";
    case AUTH_ERROR_CODES.USER_SUSPENDED:
      return "이용이 정지된 계정입니다. 고객센터에 문의해주세요.";
    default:
      return response.message || "로그인 중 오류가 발생했습니다.";
  }
};

/**
 * 로그인 성공 여부 확인
 */
export const isLoginSuccess = (
  response: LoginResponse
): response is LoginResponse & { success: true } => {
  return response.success === true;
};

/**
 * Access Token 저장/조회/삭제
 */
export const saveAccessToken = (token: string): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("accessToken", token);
  }
};

export const getAccessToken = (): string | null => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("accessToken");
  }
  return null;
};

export const removeAccessToken = (): void => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("accessToken");
  }
};

/**
 * 약관 동의 여부 저장/조회
 */
export const saveTermsAgreement = (hasAgreed: boolean): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("hasAgreedToTerms", hasAgreed.toString());
  }
};

export const getTermsAgreement = (): boolean => {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("hasAgreedToTerms");
    return stored === "true";
  }
  return false;
};

/**
 * 사용자 역할 저장/조회/삭제
 */
export const saveUserRole = (role: string): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("userRole", role);
  }
};

export const getUserRole = (): string | null => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("userRole");
  }
  return null;
};

export const removeUserRole = (): void => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("userRole");
  }
};

/**
 * ⚠️ HttpOnly 쿠키 전략에서는 refreshToken을 JS에서 읽거나 지울 수 없습니다.
 * 아래 두 함수는 미사용 처리(보안상 권장되는 방식).
 */

// export const getRefreshToken = (): string | null => null;
// export const removeRefreshToken = (): void => {};
