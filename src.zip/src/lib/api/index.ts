export * as AuthAPI from "./services/auth";
export * as UsersAPI from "./services/users";
export * as AnalyzerAPI from "./services/analyzer";
export * as AnalyteAPI from "./services/analyte";
export * as FilesAPI from "./services/files";
export * as InternalAPI from "./services/internal";