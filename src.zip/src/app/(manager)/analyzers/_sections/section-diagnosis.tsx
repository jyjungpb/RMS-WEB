// app/analyzers/_sections/section-diagnosis.tsx
"use client";
export default function DiagnosisSection() {
  return <div className="p-6">자가 진단 탭 콘텐츠</div>;
}
