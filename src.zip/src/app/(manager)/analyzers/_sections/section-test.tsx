"use client";
export default function TestSection() {
  return <div className="p-6">검사 탭 콘텐츠</div>;
}
