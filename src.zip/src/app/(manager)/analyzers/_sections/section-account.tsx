// app/analyzers/_sections/section-account.tsx
"use client";
export default function AccountSection() {
  return <div className="p-6">계정관리 탭 콘텐츠</div>;
}