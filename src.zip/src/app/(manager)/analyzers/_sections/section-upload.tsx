// app/analyzers/_sections/section-upload.tsx
"use client";
export default function UploadSection() {
  return <div className="p-6">XML 업로드 탭 콘텐츠</div>;
}