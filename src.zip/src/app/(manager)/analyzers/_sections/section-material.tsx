// app/analyzers/_sections/section-material.tsx
"use client";
export default function MaterialSection() {
  return <div className="p-6">정도관리 물질 탭 콘텐츠</div>;
}
