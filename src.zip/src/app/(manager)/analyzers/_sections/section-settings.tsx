// app/analyzers/_sections/section-settings.tsx
"use client";
export default function SettingsSection() {
  return <div className="p-6">검사기 환경 설정 탭 콘텐츠</div>;
}