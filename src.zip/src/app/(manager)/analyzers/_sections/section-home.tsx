"use client";

import { Button } from "@/components/ui/button-enhanced";
import { Card, CardContent } from "@/components/ui/card";
import CommonActionCard from "@/components/dashboard/common-action-card";
import { ConnectCountCard } from "@/components/dashboard/connect_count_card";

export default function HomeSection() {
  return <div className="p-6">오류 탭 콘텐츠</div>;
}
