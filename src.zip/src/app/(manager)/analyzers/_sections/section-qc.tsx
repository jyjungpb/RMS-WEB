// app/analyzers/_sections/section-qc.tsx
"use client";
export default function QcSection() {
  return <div className="p-6">정도관리(QC) 탭 콘텐츠</div>;
}
