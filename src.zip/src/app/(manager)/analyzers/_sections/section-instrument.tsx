// app/analyzers/_sections/section-instrument.tsx
"use client";
export default function InstrumentSection() {
  return <div className="p-6">인스트러먼트 계수 탭 콘텐츠</div>;
}
