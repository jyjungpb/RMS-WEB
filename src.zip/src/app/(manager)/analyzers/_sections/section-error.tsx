// app/analyzers/_sections/section-error.tsx
"use client";
export default function ErrorSection() {
  return <div className="p-6">오류 탭 콘텐츠</div>;
}
