// src/app/analyzers/(tabs)/home/page.tsx
"use client";
import ErrorSection from "@/app/(manager)/analyzers/_sections/section-error";
export default function ErrorTabPage() {
  return <ErrorSection />;
}
