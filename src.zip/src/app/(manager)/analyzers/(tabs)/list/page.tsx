// src/app/analyzers/list/page.tsx
"use client";
import AnalyzerListSection from "@/app/(manager)/analyzers/_sections/section-home-list";

export default function HomeListViewPage() {
  return <AnalyzerListSection />; 
}

