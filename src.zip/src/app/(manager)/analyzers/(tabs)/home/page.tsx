// src/app/analyzers/(tabs)/home/page.tsx
"use client";
import HomeSection from "@/app/(manager)/analyzers/_sections/section-home";
export default function HomeTabPage() {
  return <HomeSection />;
}