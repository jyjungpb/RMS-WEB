import { redirect } from "next/navigation";

export default function AnalyzersIndexPage() {
  redirect("/analyzers/home");
}
