// src/types/navigation.ts
export type AnalyzerTab =
  | "home"
  | "test"
  | "error"
  | "upload"
  | "instrument"
  | "qc"
  | "material"
  | "diagnosis"
  | "settings"
  | "account";
