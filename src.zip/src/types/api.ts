// // API 공통 타입들

// // HTTP 메서드 타입
// export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

// // API 엔드포인트 상수
// export const API_ENDPOINTS = {
//   AUTH: {
//     LOGIN: '/api/v1/auth/login',
//     // 추후 다른 인증 관련 엔드포인트들 추가
//   },
// } as const;

// // API 기본 설정
// export const API_CONFIG = {
//   BASE_URL: process.env.NODE_ENV == 'production' ? '' : (process.env.NEXT_PUBLIC_API_BASE_URL || ''),
//   TIMEOUT: 10000, // 10초
// } as const;

// // API 에러 타입
// export interface ApiError {
//   success: false;
//   code?: number;
//   status: number;
//   message: string;
// }

// // API 성공 응답 타입
// export interface ApiSuccess<T = any> {
//   success: true;
//   status: number;
//   message: string;
//   content?: T;
// }

// // API 응답 타입 (성공/실패 통합)
// export type ApiResult<T = any> = ApiSuccess<T> | ApiError;

// // HTTP 상태 코드 상수
// export const HTTP_STATUS = {
//   OK: 200,
//   BAD_REQUEST: 400,
//   UNAUTHORIZED: 401,
//   FORBIDDEN: 403,
//   NOT_FOUND: 404,
//   INTERNAL_SERVER_ERROR: 500,
// } as const;


// src/types/api.ts
// API 공통 타입들

// HTTP 메서드 타입
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

// API 엔드포인트 상수
export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/api/v1/auth/login',
    REFRESH: '/v1/auth/token/refresh',  // ★ 추가: 인터셉터가 사용
    // LOGOUT: '/api/v1/auth/logout',   // 필요 시 사용
  },
} as const;

// API 기본 설정
export const API_CONFIG = {
  BASE_URL: process.env.NODE_ENV == 'production' ? '' : (process.env.NEXT_PUBLIC_API_BASE_URL || ''),
  TIMEOUT: 15000,
};

// API 성공/실패 타입
export interface ApiSuccess<T = any> {
  success: true;
  status: number;
  code?: number;
  message?: string;
  content: T;
}

export interface ApiError {
  success: false;
  status: number;
  code?: number;
  message?: string;
}

export type ApiResult<T = any> = ApiSuccess<T> | ApiError;

// HTTP 상태 코드 상수
export const HTTP_STATUS = {
  OK: 200,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  INTERNAL_SERVER_ERROR: 500,
} as const;
