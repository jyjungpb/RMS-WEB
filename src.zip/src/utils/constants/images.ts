import loginLogo from '@/assets/images/login_logo.svg';
import downIcon from '@/assets/images/down.svg';

export const images = { 
    loginLogo,
    downIcon,
};
 