"use client";

import React from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ErrorPopupProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  message?: string;
  subMessage?: string;
}

export default function ErrorPopup({
  isOpen,
  onClose,
  title = "오류",
  message = "요청 처리 중 오류가 발생했습니다.",
  subMessage,
}: ErrorPopupProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className="w-[240px] p-2.5 gap-2.5 bg-white border border-[#A4CFFA] shadow-[0px_4px_8px_0px_rgba(0,0,0,0.1)]"
        showCloseButton={false}
      >
        <div className="flex flex-col items-center gap-2.5">
          {/* Danger Icon */}
          <div className="w-6 h-6 relative">
            <div className="w-4 h-4 absolute top-1 left-1">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle cx="8" cy="8" r="8" fill="#E02B1D" />
                <rect x="7.2" y="3.2" width="1.6" height="9.6" fill="white" />
                <rect x="0" y="0" width="16" height="16" fill="none" />
              </svg>
            </div>
          </div>

          {/* Content */}
          <div className="flex flex-col items-center gap-1.5 px-2.5">
            <DialogTitle className="text-[10px] font-bold leading-[1.193359375em] text-center text-black">
              {title}
            </DialogTitle>
            <DialogDescription className="text-[10px] font-normal leading-[1.193359375em] text-center text-[#3A4753]">
              {message}
            </DialogDescription>
            {subMessage && (
              <DialogDescription className="text-[10px] font-normal leading-[1.193359375em] text-center text-[#3A4753]">
                {subMessage}
              </DialogDescription>
            )}
          </div>

          {/* Button */}
          <div className="flex justify-center items-center gap-6 px-6 w-[200px]">
            <Button
              onClick={onClose}
              className="w-16 h-6 bg-[#007BF7] text-white text-[8px] font-medium leading-[1.32em] rounded-md px-1 py-1"
            >
              확인
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
